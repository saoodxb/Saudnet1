# سعود للموبايل (IPTVTest)

تطبيق أندرويد لتشغيل قنوات IPTV من قائمة M3U باستخدام LibVLC.

## بناء الـ APK على GitHub (بدون أي برامج)
1. ارفع محتوى هذا المجلد كاملًا إلى مستودع GitHub (تأكد من رفع مجلد `.github`).
2. افتح تبويب **Actions** ← **Build APK** ← **Run workflow** (أو يبدأ تلقائيًا عند الرفع).
3. بعد انتهاء البناء نزّل **IPTVTest-apk** من قسم Artifacts.

## البناء محليًا
```
./gradlew assembleDebug
```
الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## تغيير القائمة
عدّل `PLAYLIST_URL` في `app/src/main/java/com/example/iptvtest/MainActivity.kt`.
إذا تركته فارغًا يقرأ من `app/src/main/assets/playlist.m3u`.
