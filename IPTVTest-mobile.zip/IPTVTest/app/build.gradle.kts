plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.iptvtest"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.iptvtest"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("org.videolan.android:libvlc-all:3.6.0")
}
