package com.example.iptvtest

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

// رابط قائمتك. اتركه "" إذا تريد القراءة فقط من الملف assets/playlist.m3u
private const val PLAYLIST_URL =
    "http://10.10.10.254/get.php?username=ali1&password=ali1&type=m3u_plus"
private const val ALL = "الكل"
private const val BLUE = "#1976D2"

data class Channel(val name: String, val url: String, val group: String)

class MainActivity : Activity() {
    private lateinit var libVlc: LibVLC
    private lateinit var vlc: MediaPlayer
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var list: ListView
    private lateinit var status: TextView
    private lateinit var tabs: LinearLayout
    private var all: List<Channel> = emptyList()
    private var shown: List<Channel> = emptyList()
    private var current = ""
    private val groupRe = Regex("group-title=\"([^\"]*)\"")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density

        libVlc = LibVLC(this, arrayListOf("--network-caching=2000", "--http-reconnect"))
        vlc = MediaPlayer(libVlc)
        videoLayout = VLCVideoLayout(this).apply { setBackgroundColor(Color.BLACK) }
        vlc.attachViews(videoLayout, null, false, false)

        // الشريط العلوي: الشعار + الاسم
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor(BLUE))
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            addView(ImageView(this@MainActivity).apply { setImageResource(R.mipmap.ic_launcher) },
                LinearLayout.LayoutParams((36 * d).toInt(), (36 * d).toInt()))
            addView(TextView(this@MainActivity).apply {
                text = "سعود للموبايل"
                setTextColor(Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setPadding((12 * d).toInt(), 0, 0, 0)
            })
        }

        status = TextView(this).apply { text = "جاري التحميل..."; setTextColor(Color.DKGRAY); setPadding(24, 16, 24, 16) }
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scroll = HorizontalScrollView(this).apply { addView(tabs) }
        list = ListView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(videoLayout, LinearLayout.LayoutParams(MATCH_PARENT, (220 * d).toInt()))
            addView(status)
            addView(scroll)
            addView(list, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            root.isForceDarkAllowed = false
            window.decorView.isForceDarkAllowed = false
        }
        setContentView(root)

        list.setOnItemClickListener { _, _, i, _ -> play(shown[i]) }

        vlc.setEventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> runOnUiThread { status.text = current }
                MediaPlayer.Event.EncounteredError ->
                    runOnUiThread { status.text = "تعذر تشغيل القناة: $current" }
            }
        }

        thread { load() }
    }

    private fun play(ch: Channel) {
        current = ch.name
        status.text = "جاري التشغيل: ${ch.name}"
        val media = Media(libVlc, Uri.parse(ch.url))
        vlc.media = media
        media.release()
        vlc.play()
    }

    private fun load() {
        var channels = emptyList<Channel>()
        var err = ""
        if (PLAYLIST_URL.isNotEmpty()) {
            try {
                val c = URL(PLAYLIST_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 30000
                channels = parseM3u(c.inputStream.bufferedReader().readLines())
            } catch (e: Exception) {
                err = e.message ?: ""
            }
        }
        if (channels.isEmpty()) {
            try {
                channels = parseM3u(assets.open("playlist.m3u").bufferedReader().readLines())
            } catch (e: Exception) {
            }
        }
        runOnUiThread {
            all = channels
            if (channels.isEmpty()) {
                status.text = "ما لقيت قنوات. $err"
            } else {
                buildTabs()
                select(ALL)
            }
        }
    }

    private fun buildTabs() {
        val d = resources.displayMetrics.density
        val groups = listOf(ALL) + all.map { it.group }.filter { it.isNotEmpty() }.distinct()
        tabs.removeAllViews()
        for (g in groups) {
            tabs.addView(TextView(this).apply {
                text = g
                tag = g
                setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
                setOnClickListener { select(g) }
            })
        }
    }

    private fun select(group: String) {
        for (i in 0 until tabs.childCount) {
            val t = tabs.getChildAt(i) as TextView
            val on = t.tag == group
            t.setBackgroundColor(if (on) Color.parseColor(BLUE) else Color.TRANSPARENT)
            t.setTextColor(if (on) Color.WHITE else Color.DKGRAY)
        }
        shown = if (group == ALL) all else all.filter { it.group == group }
        list.adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_list_item_1, shown.map { it.name }) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(Color.BLACK)
                return v
            }
        }
        status.text = "$group — ${shown.size}"
    }

    private fun parseM3u(lines: List<String>): List<Channel> {
        val out = mutableListOf<Channel>()
        var name: String? = null
        var group = ""
        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = groupRe.find(line)?.groupValues?.get(1) ?: ""
            } else if (line.isNotEmpty() && !line.startsWith("#") && name != null) {
                out.add(Channel(name, line, group))
                name = null
            }
        }
        return out
    }

    override fun onStop() {
        vlc.pause()
        super.onStop()
    }

    override fun onDestroy() {
        vlc.stop()
        vlc.detachViews()
        vlc.release()
        libVlc.release()
        super.onDestroy()
    }
}
